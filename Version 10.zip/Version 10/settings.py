WIDTH = 1200 #Fensterbreite #24Tiles
HEIGHT = 900 #Fensterhöhe #18tiles
FPS = 60 #Bilder pro Sekunde
TILESIZE = 50  #Jedes Tile ist 50x50 Pixel groß
colorkey = (255, 255, 255) #um den weißen Hintergrund der Bilder zu entfernen
